/**
 * Begin by requiring appjs.
 **/
var app = require('appjs'),
    fs = require('fs');

app.serveFilesFrom(__dirname + '/content');

var window = app.createWindow({
  width           : 640,
  height          : 460,
  autoResize      : false, // resizes in response to html content
  resizable       : true,  // controls whether window is resizable by user
  showChrome      : true,  // show border and title bar
  icons           : __dirname + '/content/icons' // icons that represent the application
});

window.on('create', function () {
  console.log("Window Created");
  this.frame.show();
  this.frame.center();
});

window.on('ready', function () {
  console.log("Window Ready");

  var f12 = function (e) {
        return e.keyIdentifier === 'F12';
      },
      control_shift_j = function (e) {
        return e.ctrlKey && e.shiftKey && e.keyCode === 74;
      };

  this.addEventListener('keydown', function (e) {
    if (f12(e) || control_shift_j(e)) {
      // Open the Chromium dev tools.
      window.frame.openDevTools();
    }
  });
});

window.on('close', function () {
  console.log('Window Closed');
});

app.router.get('/open', function () {
  window.frame.openDialog({
      type: "open", // The type of dialog (open|save|font|color)
      initialValue: "/home/", // The initial folder
      acceptTypes: [ // The type of file to open
        "*.log"
      ],
      multiSelect: false, // Allow the user to select multiple files
      dirSelect: false // Allow the user to select a directory
    },
    // The method is async. The callback is call whith an error object and
    // an array of the files path.
    function (err, files) {
      if (err) {
        throw err;
      }

      if (files.length === 0) {
        console.log("no file chosen");
        return;
      }

      fs.readFile(files[0], 'UTF8', function (err, data) {
        if (err) {
          throw err;
        }

        window.document.getElementById('fileContent').innerText = data;
      });
    });
});
